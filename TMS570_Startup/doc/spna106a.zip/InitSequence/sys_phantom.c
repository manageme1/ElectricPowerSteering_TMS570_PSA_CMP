/** @file sys_phantom.c 
*   @brief Phantom Interrupt Source File
*   @date 04.October.2011
*   @version 1.02.000
*
*   This file contains:
*   - Phantom Interrupt Handler
*/

/* (c) Texas Instruments 2009-2011, All rights reserved. */

/* USER CODE BEGIN (0) */
/* USER CODE END */


/* Phantom Interrupt Handler */

/* USER CODE BEGIN (1) */
/* USER CODE END */

#pragma INTERRUPT(phantomInterrupt, IRQ)

void phantomInterrupt(void)
{
/* USER CODE BEGIN (2) */
/* USER CODE END */
}

/* USER CODE BEGIN (3) */
/* USER CODE END */
