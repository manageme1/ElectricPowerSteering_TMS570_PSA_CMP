/** @file pbist.h
*   @brief PBIST Driver Definition File
*   @date 12.October.2011
*   @version 1.00.000
*   
*/

/* (c) Texas Instruments 2009-2010, All rights reserved. */


#ifndef __PBIST_H__
#define __PBIST_H__

/* PBIST General Definitions */

/** @struct pbistBase
*   @brief PBIST Base Register Definition
*
*   This structure is used to access the PBIST module egisters.
*/
/** @typedef pbistBASE_t
*   @brief PBIST Register Frame Type Definition
*
*   This type is used to access the PBIST Registers.
*/
typedef volatile struct pbistBase
{
    uint32_t RAMT;			/* 0x0160: RAM Configuration Register */
    uint32_t DLR;			/* 0x0164: Datalogger Register */
    uint32_t : 32U;			/* 0x0168 */
	uint32_t : 32U;			/* 0x016C */
	uint32_t : 32U;			/* 0x0170 */
	uint32_t : 32U;			/* 0x0174 */
	uint32_t : 32U;			/* 0x0178 */
	uint32_t : 32U;			/* 0x017C */
    uint32_t PACT;			/* 0x0180: PBIST Activate Register */
    uint32_t PBISTID;		/* 0x0184: PBIST ID Register */
    uint32_t OVER;			/* 0x0188: Override Register */
    uint32_t : 32U;			/* 0x018C */
    uint32_t FSRF0;			/* 0x0190: Fail Status Fail Register 0 */
	uint32_t FSRF1;			/* 0x0194: Fail Status Fail Register 1 */
    uint32_t FSRC0;			/* 0x0198: Fail Status Count Register 0 */
    uint32_t FSRC1;			/* 0x019C: Fail Status Count Register 1 */
    uint32_t FSRA0;			/* 0x01A0: Fail Status Address 0 Register */
    uint32_t FSRA1;			/* 0x01A4: Fail Status Address 1 Register */
    uint32_t FSRDL0;		/* 0x01A8: Fail Status Data Register 0 */
    uint32_t : 32U;			/* 0x01AC */
    uint32_t FSRDL1;		/* 0x01B0: Fail Status Data Register 1 */
    uint32_t : 32U;			/* 0x01B4 */
    uint32_t : 32U;			/* 0x01B8 */
    uint32_t : 32U;			/* 0x01BC */
    uint32_t ROM;			/* 0x01C0: ROM Mask Register */
    uint32_t ALGO;			/* 0x01C4: Algorithm Mask Register */
    uint32_t RINFOL;		/* 0x01C8: RAM Info Mask Lower Register */
    uint32_t RINFOU;		/* 0x01CC: RAM Info Mask Upper Register */
} pbistBASE_t;

#define pbistREG   ((pbistBASE_t *)0xFFFFE560U)

#endif
