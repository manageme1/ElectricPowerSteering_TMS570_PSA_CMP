/** @file sys_startup.c 
*   @brief Startup Source File
*   @date 06.June.2010
*   @version 1.01.001
*
*   This file contains:
*   - Include Files
*   - Type Definitions
*   - External Functions
*   - VIM RAM Setup
*   - Startup Routine
*   .
*   which are relevant for the Startup.
*/

/* (c) Texas Instruments 2009-2010, All rights reserved. */

/* USER CODE BEGIN (0) */
/* USER CODE END */


/* Include Files */

#include "sys_common.h"
#include "system.h"
#include "sys_vim.h"
#include "sys_core.h"
#include "sys_memory.h"

/* USER CODE BEGIN (1) */

#include "sys_esm.h"
#include "stc.h"
#include "pbist.h"
#include "efc.h"

#include "mibadc.h"
#include "dcan.h"
#include "mibspi.h"
#include "nhet.h"
#include "htu.h"

/* USER CODE END */


/* Type Definitions */

typedef void (*handler_fptr)(const uint8_t *in, uint8_t *out);

/* USER CODE BEGIN (2) */
/* USER CODE END */


/* External Functions */

#pragma WEAK(__TI_Handler_Table_Base)
#pragma WEAK(__TI_Handler_Table_Limit)
#pragma WEAK(__TI_CINIT_Base)
#pragma WEAK(__TI_CINIT_Limit)

extern uint32_t   __TI_Handler_Table_Base;
extern uint32_t   __TI_Handler_Table_Limit;
extern uint32_t   __TI_CINIT_Base;
extern uint32_t   __TI_CINIT_Limit;
extern uint32_t   __TI_PINIT_Base;
extern uint32_t   __TI_PINIT_Limit;
extern uint32_t * __binit__;

extern void main(void);
extern void exit(void);

/* USER CODE BEGIN (3) */

extern void esmInit(void);
extern void muxInit(void);
extern void rtiCompare0Interrupt(void);

void _esmCcmErrorsClear_(void);
void setupPLL(void);
void trimLPO(void);
void setupFlash(void);
void periphInit(void);
void mapClocks(void);
void ccmSelfCheck(void);
void ccmFail(unsigned int);
void stcSelfCheck(void);
void stcSelfCheckFail(void);
void cpuSelfTest(void);
void cpuSelfTestFail(void);

void afterSTC(void);

void pbistSelfCheck(void);
void pbistRun(unsigned int, unsigned int);
void pbistStop(void);
void pbistSelfCheckFail(void);

void efcCheck(void);
void efcSelfTest(void);
unsigned int efcStuckZeroTest(void);
unsigned int checkEFCSelfTest(void);
void efcClass1Error(void);
void efcClass2Error(void);

void fmcBus2Check(void);
void fmcECCcheck(void);
void fmcClass1Error(void);
void fmcClass2Error(void);

void checkB0RAMECC(void);
void checkB1RAMECC(void);
void tcramClass1Error(void);
void tcramClass2Error(void);

void checkFlashECC(void);
void flashClass1Error(void);
void flashClass2Error(void);

void vimParityCheck(void);
void dmaParityCheck(void);
void adc1ParityCheck(void);
void adc2ParityCheck(void);
void nhet1ParityCheck(void);
void htu1ParityCheck(void);
void nhet2parityCheck(void);
void htu2ParityCheck(void);
void dcan1ParityCheck(void);
void dcan2ParityCheck(void);
void dcan3ParityCheck(void);
void mibspi1ParityCheck(void);
void mibspi3parityCheck(void);
void mibspi5ParityCheck(void);

#define flash1bitError	(*(unsigned int *) 0xF00803F0)
#define flash2bitError	(*(unsigned int *) 0xF00803F8)

#define tcramA1bitError	(*(unsigned int *)(0x08400000))
#define tcramA2bitError (*(unsigned int *)(0x08400010))

#define tcramB1bitError	(*(unsigned int *)(0x08400008))
#define tcramB2bitError (*(unsigned int *)(0x08400018))

#define tcramA1bit		(*(unsigned int *)0x08000000)
#define tcramA2bit		(*(unsigned int *)0x08000010)

#define tcramB1bit		(*(unsigned int *)0x08000008)
#define tcramB2bit		(*(unsigned int *)0x08000018)

#define flashBadECC		(*(unsigned int *)0x20080000)

#define CCMSR 			(*(unsigned int *)0xFFFFF600U)
#define CCMKEYR			(*(unsigned int *)0xFFFFF604U)

#define ADC1RAM			(*(unsigned int *)0xFF3E0000U)
#define ADC2RAM			(*(unsigned int *)0xFF3A0000U)

#define ADC1RAMPAR		(*(unsigned int *)0xFF3E1000U)
#define ADC2RAMPAR		(*(unsigned int *)0xFF3A1000U)

#define DCAN1RAMPAR		(*(unsigned int *)0xFF1E0010U)
#define DCAN2RAMPAR		(*(unsigned int *)0xFF1C0010U)
#define DCAN3RAMPAR		(*(unsigned int *)0xFF1A0010U)

#define DCAN1RAMLOC		(*(unsigned int *)0xFF1E0000U)
#define DCAN2RAMLOC		(*(unsigned int *)0xFF1C0000U)
#define DCAN3RAMLOC		(*(unsigned int *)0xFF1A0000U)

#define SPI1RAMPARLOC	(*(unsigned int *)0xFF0E0400U)
#define SPI3RAMPARLOC	(*(unsigned int *)0xFF0C0400U)
#define SPI5RAMPARLOC	(*(unsigned int *)0xFF0A0400U)

#define SPI1RAMLOC		(*(unsigned int *)0xFF0E0000U)
#define SPI3RAMLOC		(*(unsigned int *)0xFF0C0000U)
#define SPI5RAMLOC		(*(unsigned int *)0xFF0A0000U)

#define NHET1RAMPARLOC	(*(unsigned int *)0xFF462000U)
#define NHET1RAMLOC		(*(unsigned int *)0xFF460000U)

#define NHET2RAMPARLOC	(*(unsigned int *)0xFF442000U)
#define NHET2RAMLOC		(*(unsigned int *)0xFF440000U)

#define HTU1PARLOC		(*(unsigned int *)0xFF4E0200U)
#define HTU2PARLOC		(*(unsigned int *)0xFF4C0200U)

#define HTU1RAMLOC		(*(unsigned int *)0xFF4E0000U)
#define HTU2RAMLOC		(*(unsigned int *)0xFF4C0000U)

#define FSM_WR_ENA		(*(unsigned int *)0xFFF87288U)
#define EEPROM_CONFIG	(*(unsigned int *)0xFFF872B8U)

#define SP_RAM_GRPS_TMS	0x08310020
#define SP_RAM_GRPS_RM	0x0D300020
#define SP_RAMs			0x8

#define DP_RAM_GRPS_TMS		0x00CEFFDC
#define DP_RAM_GRPS_RM		0x02CCFFDC
#define DP_RAMs			0x4

#define RAM_INIT_MASK_TMS	0x1E57F
#define RAM_INIT_MASK_RM	0x1C57F

#define IOMM_BOOT_REG	(*(unsigned int *)0xFFFFEA20U)

#define VIM_PARFLG		(*(unsigned int *)0xFFFFFDECU)
#define VIM_PARCTL		(*(unsigned int *)0xFFFFFDF0U)
#define VIM_ADDERR		(*(unsigned int *)0xFFFFFDF4U)
#define VIM_FBPARERR	(*(unsigned int *)0xFFFFFDF8U)

#define VIMRAMPARLOC	(*(unsigned int *)0xFFF82400U)
#define VIMRAMLOC		(*(unsigned int *)0xFFF82000U)

#define DMA_PARCR		(*(unsigned int *)0xFFFFF1A8U)
#define DMA_PARADDR		(*(unsigned int *)0xFFFFF1ACU)

#define DMARAMLOC		(*(unsigned int *)0xFFF80000U)
#define DMARAMPARLOC	(*(unsigned int *)0xFFF80A00U)

/* USER CODE END */


/* Vim Ram Definition */
/** @struct vimRam
*   @brief Vim Ram Definition
*
*   This type is used to access the VIM RAM.
*/
/** @typedef vimRAM_t
*   @brief VIM RAM Type Definition
*
*   This type is used to access the Vim Ram.
*/
typedef volatile struct vimRam
{
    t_isrFuncPTR ISR[VIM_CHANNELS];
} vimRAM_t;

#define vimRAM ((vimRAM_t *)0xFFF82000U)

static const t_isrFuncPTR s_vim_init[] =
{
    &phantomInterrupt,
    &esmHighInterrupt,
    &phantomInterrupt,
    &rtiCompare0Interrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
    &phantomInterrupt,
};


/* Startup Routine */

/* USER CODE BEGIN (4) */

void setupPLL(void)
{
    /* Configure PLL control registers */
    
    /* PLL1 is used to generate a 180MHz output from a 16MHz oscillator */
	/* Use HALCoGen to generate other frequencies or if you have a different oscillator. */
    /* Initially the PLL output is configured to be 180MHz/16 = 11.25MHz */
    /* This can be increased to 180MHz in steps once the PLL has acquired lock */
    systemREG1->PLLCTL1 = 0x2F035900;
    systemREG1->PLLCTL2 = 0x04C5C249;
    
    /* PLL2 is used to generate a 80MHz output from a 16MHz oscillator */
    /* Initially the PLL output is configured to be 80MHz/16 = 5MHz */
    /* This can be increased to 80MHz in steps once the PLL has acquired lock */
    systemREG2->PLLCTL3 = 0x2F031300;

	/* Enable PLL(s) to start up */
	/* main PLL is clock source # 1, second PLL is clock source # 6 */
	systemREG1->CSDISCLR = 0x42;
}

void trimLPO(void)
{
    /* Configure LPO */
    /* Load TRIM values from OTP if present else load user defined values */
    if(LPO_TRIM_VALUE != 0xFFFF)
    {
    
        systemREG1->LPOMONCTL  = (1U << 24U)
                                | LPO_TRIM_VALUE;
    }
    else
    {

    	systemREG1->LPOMONCTL 	= (1U << 24U)
                                 | (16U << 8U)
                                 | 8U;
    }
}

void setupFlash(void)
{
    /* Setup flash read mode, address wait states and data wait states */
    flashWREG->FRDCNTL =  0x00000000U 
                       | (3U << 8U) 
                       | (1U << 4U) 
                       |  1U;

    /* Setup flash access wait states for bank 7 */
    FSM_WR_ENA = 0x5;
    EEPROM_CONFIG = 0x00030002;

    /* Disable write access to flash state machine registers */
    FSM_WR_ENA = 0xA;

	/* We are leaving the flash banks' and pump's fall-back mode as ACTIVE */
	/* This needs to be changed for any application that wants to turn off any unused flash bank */
}

void periphInit(void)
{
	/* Release peripherals from reset and enable clocks to all peripherals */
    /* - Power-up all peripharals */
    pcrREG->PSPWRDWNCLR0 = 0xFFFFFFFFU;
    pcrREG->PSPWRDWNCLR1 = 0xFFFFFFFFU;
    pcrREG->PSPWRDWNCLR2 = 0xFFFFFFFFU;
    pcrREG->PSPWRDWNCLR3 = 0xFFFFFFFFU;

    /* Enable Peripherals */
    systemREG1->PENA = 1U;
}

void mapClocks(void)
{
    /* Setup synchronous peripheral clock dividers for VCLK1, VCLK2, VCLK3 */
    systemREG1->VCLKR   = 1U;
    systemREG1->VCLK2R  = 1U;
    systemREG2->VCLK3R  = 1U;

	/* Wait for PLL(s) to acquire lock and become available */
	while ((systemREG1->CSVSTAT & 0x42) != 0x42);
	
	/* Map device clock domains to desired sources and configure top-level dividers */
	/* All clock domains are working off the default clock sources until now */
	/* The below assignments can be easily modified using the HALCoGen GUI */
    
    /* Setup GCLK, HCLK and VCLK clock source for normal operation, power down mode and after wakeup */
    systemREG1->GHVSRC = (SYS_PLL1 << 24U) 
                       | (SYS_PLL1 << 16U) 
                       |  SYS_PLL1;
                       
    /* Setup synchronous peripheral clock dividers for VCLK1, VCLK2, VCLK3 */
    systemREG1->VCLKR   = 1U;
    systemREG1->VCLK2R  = 1U;
    systemREG2->VCLK3R  = 1U;

    /* Setup RTICLK */
    systemREG1->RCLKSRC = (1U << 24U)
                        | (SYS_VCLK << 16U) 
                        | (1U << 8U)  
                        |  SYS_VCLK;

    /* Setup asynchronous peripheral clock sources for AVCLK1 and AVCLK2 */
    systemREG1->VCLKASRC = (SYS_PLL2 << 8U)
                          |  SYS_OSC;

    systemREG2->VCLKACON1 = (1U << 24) 
                           | 1 << 20U 
                           | (SYS_VCLK << 16)
                           | (1U << 1) 
                           | 1 << 4U 
                           | SYS_VCLK;

	/* Now the PLLs are locked and the PLL outputs can be sped up */
	/* The R-divider was programmed to be 0xF. Now this divider is changed to 0 */
	systemREG1->PLLCTL1 &= 0xE0FFFFFF;
	systemREG2->PLLCTL3 &= 0xE0FFFFFF;
}

void ccmSelfCheck(void)
{
	/* Run a diagnostic check on the CCM-R4F module */
	/* This step ensures that the CCM-R4F can actually indicate an error */

	CCMKEYR = 0x6;								// Configure CCM in self-test mode
	while ((CCMSR & 0x100) != 0x100);			// Wait for CCM self-test to complete
	
	/* Check if there was an error during the self-test */
	if ((CCMSR & 0x1) == 0x1)
	{
		ccmFail(0);								// STE is set
	}
	else
	{
		/* Check CCM-R4 self-test error flag by itself (without compare error) */
		CCMKEYR = 0xF;						// Configure CCM in self-test error-forcing mode
		if ((esmREG->ESTATUS1[0] & 0x80000000) != 0x80000000)
		{
			ccmFail(1);						// ESM flag is not set
		}
		else
		{
			esmREG->ESTATUS1[0] = 0x80000000;	// clear ESM group1 channel 31 flag
			
			CCMKEYR = 0x9;						// Configure CCM in error-forcing mode
			if ((esmREG->ESTATUS1[1] & 0x4) != 0x4)		// check if compare error flag is set
			{
				ccmFail(2);								// ESM flag is not set
			}
			else
			{
				esmREG->ESTATUS1[1] = 0x4;				// clear ESM group2 channel 2 flag
				esmREG->ESTATUS5EMU = 0x4;				// clear ESM group2 shadow status flag
				esmREG->ESTATUS1[0] = 0x80000000;		// ESM self-test error needs to also be cleared
				
				/* Clear CCM-R4 CMPE flag */
				CCMSR = 0x00010000;

				/* Return CCM-R4 to lock-step mode */
				CCMKEYR = 0x0;
				
				esmREG->KEY = 0x5;						// The nERROR pin will become inactive once the LTC counter expires
			}
		}
	}
}

void ccmFail(unsigned int x)
{
	if (x == 0)
	{
		/* CCM-R4 is not able to flag a compare error in self-test mode.
		 * Lock-step operation cannot be verified.
		 */
	}
	else if (x == 1)
	{
		/* CCM-R4 self-test error flag is not set in ESM register.
		 * Could be due to a connection issue inside the part.
		 */
	}
	else if (x == 2)
	{
		/* CCM-R4 compare error flag is not set in ESM.
		 * Lock-step operation cannot be verified.
		 */
	}
}

void stcSelfCheck(void)
{
	volatile int i = 0;

	/* Run a diagnostic check on the CPU self-test controller */
	/* First set up the STC clock divider as STC is only supported up to 90MHz */
	systemREG2->STCCLKDIV = 0x01000000;					// STC clock is now normal mode CPU clock frequency/2 = 180MHz/2
	stcREG->STCGCR0 = 0x00010001;						// Select one test interval, restart self-test next time, 0x00010001
	stcREG->STCSCSCR = 0x1A;							// Enable comparator self-check and stuck-at-0 fault insertion in CPU, 0x1A
	stcREG->STCTPR = 0xFFFFFFFF;						// Maximum time-out period

	for (i=0; i<16; i++);								// wait for 16 VBUS clock cycles at least

	stcREG->STCGCR1 = 0xA;								// Enable self-test
	
	for (i=0; i<16; i++);								// wait for 16 VBUS clock cycles at least

	asm("	WFI");										// Idle the CPU so that the self-test can start
	asm("	NOP");
	asm("	NOP");
	asm("	NOP");
	asm("	NOP");
}

void cpuSelfTest(void)
{
	volatile int i = 0;

	stcREG->STCGCR0 = 0x00180001;						// Run all 24 test intervals starting from interval 0

	for (i=0; i<16; i++);								// wait for 16 VBUS clock cycles at least

	stcREG->STCGCR1 = 0xA;								// Enable self-test
	
	asm("	WFI");										// Idle the CPU so that the self-test can start
	asm("	NOP");
	asm("	NOP");
}

void pbistSelfCheck(void)
{
	int i = 0;
	/* Run a diagnostic check on the memory self-test controller */
	/* First set up the PBIST ROM clock as this clock frequency is limited to 90MHz */
	systemREG1->MSTGCR |= 0x00000100;					// PBIST ROM clock frequency = HCLK frequency /2
	systemREG1->MSINENA = 0x1;							// Enable PBIST controller
	systemREG1->MSTGCR &= ~(0xF);						// clear MSTGENA field
	systemREG1->MSTGCR |= 0xA;							// Enable PBIST self-test
	
	for (i = 0; i < 32; i++);							// software loop to wait at least 32 VCLK cycles
	
	pbistREG->PACT = 0x3;								// Enable PBIST clocks and ROM clock
	pbistREG->ALGO = 0x00000004;						// Select algo#3, march13n to be run
	pbistREG->RINFOL = 0x1;								// Select RAM Group 1, which is actually the PBIST ROM
	pbistREG->OVER = 0x0;								// ROM contents will not override ALGO and RINFOx settings
	pbistREG->ROM = 0x3;								// Algorithm code is loaded from ROM
	pbistREG->DLR = 0x14;								// Start PBIST
	
	while ((systemREG1->MSTCGSTAT & 0x1) != 0x1);		// wait until memory self-test done is indicated
	
	if (((pbistREG->FSRF0 & 0x1) != 0x1) & ((pbistREG->FSRF1 & 0x1) != 0x1))
	{
		// no failure was indicated even if the march13n algorithm was run on a ROM
		pbistSelfCheckFail();
	}
	else												// PBIST self-check has passed
	{
		pbistREG->PACT = 0x0;							// disable PBIST clocks and ROM clock
		systemREG1->MSTGCR &= ~(0xF);					// disable PBIST
		systemREG1->MSTGCR |= 0x5;
	}
}

void pbistSelfCheckFail(void)
{
	/* The PBIST controller is not capable of reporting a failure.
	 * PBIST cannot be used to verify memory integrity.
	 * Need custom handler here.
	 */
}

void pbistRun(unsigned int raminfoL, unsigned int algomask)
{
	int i = 0;
	systemREG1->MSTGCR |= 0x00000100;					// PBIST ROM clock frequency = HCLK frequency /2
	systemREG1->MSINENA = 0x1;							// Enable PBIST controller
	systemREG1->MSTGCR &= ~(0xF);						// clear MSTGENA field
	systemREG1->MSTGCR |= 0xA;							// Enable PBIST self-test
	
	for (i = 0; i < 32; i++);							// software loop to wait at least 32 VCLK cycles
	
	pbistREG->PACT = 0x3;								// Enable PBIST clocks and ROM clock
	pbistREG->ALGO = algomask;						// Select all algorithms to be tested
	pbistREG->RINFOL = raminfoL;						// Select RAM groups
	pbistREG->RINFOU = 0x00000000;						// Select all RAM groups
	pbistREG->OVER = 0x0;								// ROM contents will not override RINFOx settings
	pbistREG->ROM = 0x3;								// Algorithm code is loaded from ROM
	pbistREG->DLR = 0x14;								// Start PBIST
}

void pbistStop(void)
{
	pbistREG->PACT = 0x0;							// disable pbist clocks and ROM clock
	systemREG1->MSTGCR &= ~(0xF);
	systemREG1->MSTGCR |= 0x5;
}

void efcCheck(void)
{
	unsigned int efcStatus = 0;
	
	efcStatus = efcREG->ERROR;						// read the EFC Error Status Register
		
	if (efcStatus == 0x0)
	{
		if (efcStuckZeroTest())						// run stuck-at-zero test and check if it passed
		{
			efcSelfTest();							// start EFC ECC logic self-test
		}
		else
		{
			efcClass2Error();						// EFC output is stuck-at-zero, device operation unreliable
		}
	}
	else											// EFC Error Register is not zero
	{
		if (efcStatus == 0x15)						// one-bit error detected during autoload
		{
			efcSelfTest();							// start EFC ECC logic self-test
		}
		else
		{
			efcClass2Error();						// Some other EFC error was detected
		}
	}
}

unsigned int efcStuckZeroTest(void)
{
	unsigned int result = 0;
  	unsigned int error_checks = EFC_INSTRUCTION_INFO_EN  | 
							  	EFC_INSTRUCTION_ERROR_EN | 
							  	EFC_AUTOLOAD_ERROR_EN 	 | 
							  	EFC_SELF_TEST_ERROR_EN   ;
	
	// configure the output enable for auto load error , instruction info,
  	// instruction error, and self test error using boundary register 
  	// and drive values one across all the errors
  	efcREG->BOUNDARY = (OUTPUT_ENABLE | error_checks);
  	
	// Read from the pin register. This register holds the current values 
  	// of above errors. This value should be 0x5c00.If not at least one of
  	// the above errors is stuck at 0.
	if ((efcREG->PINS & 0x5C00) == 0x5C00)
	{
		// check if the ESM group1 channels 40 is set and group3 channel 2 is set
		if (((esmREG->ESTATUS4[0] & 0x200) == 0x200) & ((esmREG->ESTATUS1[2] & 0x2) == 0x2))
		{
			result = 1;									// stuck-at-zero test passed
		}
	}
	// put the pins back low
	efcREG->BOUNDARY = OUTPUT_ENABLE;
	esmREG->ESTATUS4[0] = 0x300;				// clear group1 flags
	esmREG->ESTATUS1[2] = 0x2;					// clear group3 flag
	esmREG->KEY = 0x5;							// The nERROR pin will become inactive once the LTC counter expires

	return result;
}
	
void efcSelfTest(void)
{
	// configure self-test cycles
	efcREG->SELF_TEST_CYCLES = 0x258;
	
	// configure self-test signature
	efcREG->SELF_TEST_SIGN = 0x5362F97F;
	
	// configure boundary register to start ECC self-test
	efcREG->BOUNDARY = 0x0000200F;
}

unsigned int checkEFCSelfTest(void)
{
	unsigned int result = 0;
	// wait until EFC self-test is done
	while(!(efcREG->PINS & EFC_SELF_TEST_DONE));
	
	// check if EFC self-test error occurred
	if (!(efcREG->PINS & EFC_SELF_TEST_ERROR) & !(efcREG->ERROR & SELF_TEST_ERROR))
	{
		if ((esmREG->ESTATUS4[0] & 0x100) != 0x100)		// check if EFC self-test error is set
		{
			result = 1;
		}
	}
	return result;
}

void efcClass1Error(void)
{
	/* Autoload error was detected during device power-up, and device operation is not reliable. */
	while(1);
}

void efcClass2Error(void)
{
	/* The ECC logic inside the eFuse controller is not operational. Device operation is not reliable. */
	while(1);
}

void fmcBus2Check(void)
{
	flashWREG->FEDACCTRL1 = 0x000A060A;		// enable ECC logic inside FMC

	if (esmREG->ESTATUS1[0] & 0x40)
	{
		// a 1-bit error was detected during flash OTP read by flash module
		// run a self-check on ECC logic inside FMC
		esmREG->ESTATUS1[0] = 0x40;				// clear ESM group1 channel 6 flag
		fmcECCcheck();
	}
	else										// no 2-bit or 1-bit error detected during power-up
	{
		fmcECCcheck();
	}
}

void fmcECCcheck(void)
{
	volatile unsigned int otpread;
	volatile unsigned int temp;

	otpread = flash1bitError;				// read location with deliberate 1-bit error
	if (esmREG->ESTATUS1[0] & 0x40)
	{
		// 1-bit failure was indicated and corrected
		flashWREG->FEDACSTATUS = 0x00010006;
		esmREG->ESTATUS1[0] = 0x40;			// clear ESM group1 channel 6 flag

		otpread = flash2bitError;			// read location with deliberate 2-bit error
		if (esmREG->ESTATUS1[2] & 0x80)
		{
			// 2-bit failure was detected correctly
			temp = flashWREG->FUNCERRADD;
			flashWREG->FEDACSTATUS = 0x00020100;
			esmREG->ESTATUS1[2] = 0x80;		// clear ESM group3 channel 7
			esmREG->KEY = 0x5;				// The nERROR pin will become inactive once the LTC counter expires

		}
		else
		{
			fmcClass2Error();				// ECC logic inside FMC cannot detect 2-bit error
		}
	}
	else
	{
		fmcClass2Error();					// ECC logic inside FMC cannot detect 1-bit error
	}
}

void fmcClass1Error(void)
{
	// there was a multi-bit error detected during the reset configuration word read from the OTP
	// This affects the device power domains, endianness, and exception handling ISA
	// Device operation is not reliable.
	while(1);
}

void fmcClass2Error(void)
{
	// The ECC logic inside FMC used to protect against 1-bit and 2-bit errors in OTP and EEPROM banks
	// is not operational. Device operation is not reliable.
	while(1);
}

void checkB0RAMECC(void)
{
	volatile unsigned int ramread = 0;

	tcram1REG->RAMCTRL = 0x0005010A;			// enable writes to ECC RAM, enable ECC error response
	tcram2REG->RAMCTRL = 0x0005010A;

	tcram1REG->RAMTHRESHOLD = 0x1;				// the first 1-bit error will cause an error response
	tcram2REG->RAMTHRESHOLD = 0x1;

	tcram1REG->RAMINTCTRL = 0x1;				// allow SERR to be reported to ESM
	tcram2REG->RAMINTCTRL = 0x1;

	tcramA1bitError ^= 0x1;						// cause a 1-bit ECC error
	tcram1REG->RAMCTRL = 0x0005000A;			// disable writes to ECC RAM
	tcram2REG->RAMCTRL = 0x0005000A;

	ramread = tcramA1bit;						// read from location with 1-bit ECC error
	if (!((tcram1REG->RAMERRSTATUS & 1) || (tcram2REG->RAMERRSTATUS & 1)))	// SERR not set in TCRAM1 or TCRAM2 modules
	{
		tcramClass2Error();						// TCRAM module does not reflect 1-bit error reported by CPU
	}
	else
	{
		tcram1REG->RAMERRSTATUS = 0x1;			// clear SERR flag
		tcram2REG->RAMERRSTATUS = 0x1;
		esmREG->ESTATUS1[0] = 0x14000000;		// clear status flags for ESM group1 channels 26 and 28
	}

	tcram1REG->RAMCTRL = 0x0005010A;			// enable writes to ECC RAM, enable ECC error response
	tcram2REG->RAMCTRL = 0x0005010A;

	tcramA2bitError ^= 0x3;						// cause a 2-bit ECC error
	ramread = tcram1REG->RAMCTRL;
	ramread = tcram2REG->RAMCTRL;

	ramread = tcramA2bit;						// read from location with 2-bit ECC error
												// this will cause a data abort to be generated
}

void checkB1RAMECC(void)
{
	volatile unsigned int ramread = 0;

	tcram1REG->RAMCTRL = 0x0005010A;			// enable writes to ECC RAM, enable ECC error response
	tcram2REG->RAMCTRL = 0x0005010A;

	tcram1REG->RAMTHRESHOLD = 0x1;				// the first 1-bit error will cause an error response
	tcram2REG->RAMTHRESHOLD = 0x1;

	tcram1REG->RAMINTCTRL = 0x1;				// allow SERR to be reported to ESM
	tcram2REG->RAMINTCTRL = 0x1;

	tcramB1bitError ^= 0x1;						// cause a 1-bit ECC error
	tcram1REG->RAMCTRL = 0x0005000A;			// disable writes to ECC RAM
	tcram2REG->RAMCTRL = 0x0005000A;

	ramread = tcramB1bit;						// read from location with 1-bit ECC error
	if (!((tcram1REG->RAMERRSTATUS & 1) || (tcram2REG->RAMERRSTATUS & 1)))	// SERR not set in TCRAM1 or TCRAM2 modules
	{
		tcramClass2Error();						// TCRAM module does not reflect 1-bit error reported by CPU
	}
	else
	{
		tcram1REG->RAMERRSTATUS = 0x1;			// clear SERR flag
		tcram2REG->RAMERRSTATUS = 0x1;
		esmREG->ESTATUS1[0] = 0x14000000;		// clear status flags for ESM group1 channels 26 and 28
	}

	tcram1REG->RAMCTRL = 0x0005010A;			// enable writes to ECC RAM, enable ECC error response
	tcram2REG->RAMCTRL = 0x0005010A;

	tcramB2bitError ^= 0x3;						// cause a 2-bit ECC error
	ramread = tcram1REG->RAMCTRL;
	ramread = tcram2REG->RAMCTRL;

	ramread = tcramB2bit;						// read from location with 2-bit ECC error
												// this will cause a data abort to be generated
}

void tcramClass1Error(void)
{
	/* TCRAM module is not capable of responding to 2-bit error indicated by CPU.
	 * Device operation is not reliable and not recommended.
	 */
	while(1);
}

void tcramClass2Error(void)
{
	/* TCRAM module is not capable of responding to 1-bit error indicated by CPU.
	 * Device operation is possible, but is prone to future multi-bit errors not being detected.
	 * Need custom handler here instead of the infinite loop.
	 */
	while(1);
}

void checkFlashECC(void)
{
	/* Routine to check operation of ECC logic inside CPU for accesses to program flash */

	volatile unsigned int flashread = 0;

	flashWREG->FEDACCTRL1 = 0x000A060A;			// Flash Module ECC Response enabled

	flashWREG->FDIAGCTRL = 0x00050007;			// Enable diagnostic mode and select diag mode 7
	flashWREG->FPAROVR = 0x00005401;			// Select ECC diagnostic mode, single-bit to be corrupted
	flashWREG->FDIAGCTRL |= 0x01000000;			// Set the trigger for the diagnostic mode

	flashread = flashBadECC;					// read a flash location from the mirrored memory map
	flashWREG->FDIAGCTRL = 0x000A0007;			// disable diagnostic mode

	/* this will have caused a single-bit error to be generated and corrected by CPU */
	if (!(flashWREG->FEDACSTATUS & 0x2))		// single-bit error not captured in flash module
	{
		flashClass2Error();
	}
	else
	{
		flashWREG->FEDACSTATUS = 0x2;				// clear single-bit error flag

		esmREG->ESTATUS1[0] = 0x40;					// clear ESM flag

		flashWREG->FDIAGCTRL = 0x00050007;			// Enable diagnostic mode and select diag mode 7
		flashWREG->FPAROVR = 0x00005A03;			// Select ECC diagnostic mode, two bits of ECC to be corrupted
		flashWREG->FDIAGCTRL |= 0x01000000;			// Set the trigger for the diagnostic mode

		flashread = flashBadECC;					// read from flash location from mirrored memory map
													// this will cause a data abort
	}

}

void flashClass1Error(void)
{
	/* Flash module not able to capture 2-bit error from CPU.
	 * Device operation not reliable.
	 */
	while(1);

}

void flashClass2Error(void)
{
	/* Flash module not able to capture 1-bit error from CPU.
	 * Device operation possible if this weakness in diagnostic is okay.
	 */
}

/* Routine to check VIM RAM parity error detection and signaling mechanism */
void vimParityCheck(void)
{
	volatile unsigned int vimramread = 0;

	VIM_PARCTL = 0x0000010A;				// Enable parity checking and parity test mode
	VIMRAMPARLOC ^= 0x1;					// flip a bit in the VIM RAM parity location
	VIM_PARCTL = 0x0000000A;				// disable parity test mode

	vimramread = VIMRAMLOC;					// cause parity error

	if (!(esmREG->ESTATUS1[0] & 0x8000))	// check if ESM group1 channel 15 is flagged
	{
		// VIM RAM parity error was not flagged to ESM.
		// Need custom routine to handle this failure instead of the infinite loop.
		while(1);
	}
	else
	{
		VIM_PARFLG = 0x1;					// clear VIM RAM parity error flag in VIM
		esmREG->ESTATUS1[0] = 0x8000;		// clear ESM group1 channel 15 flag
	}
}

/* Routine to check DMA control packet RAM parity error detection and signaling mechanism */
void dmaParityCheck(void)
{
	volatile unsigned int dmaread = 0;

	DMA_PARCR = 0x0000010A;					// Enable parity checking and parity test mode
	DMARAMPARLOC ^= 0x1;					// Flip a bit in DMA RAM parity location
	DMA_PARCR = 0x0000000A;					// Disable parity test mode

	dmaread = DMARAMLOC;					// Cause parity error

	if (!(esmREG->ESTATUS1[0] & 0x8))		// Check if ESM group1 channel 3 is flagged
	{
		// DMA RAM parity error was not flagged to ESM.
		// Need custom routine to handle this failure instead of the infinite loop.
		while(1);
	}
	else
	{
		DMA_PARADDR = 0x01000000;			// clear DMA parity error flag in DMA
		esmREG->ESTATUS1[0] = 0x8;			// clear ESM group1 channel 3 flag
	}

}
void nhet1ParityCheck(void)
{
	volatile unsigned int nhetread = 0;

	nhetREG1->PCREG = 0x0000010A;			// Set TEST mode and enable parity checking
	NHET1RAMPARLOC ^= 0x1;					// flip parity bit
	nhetREG1->PCREG = 0x0000000A;			// Disable TEST mode

	nhetread = NHET1RAMLOC;					// read to cause parity error

	if (!(esmREG->ESTATUS1[0] & 0x80))		// check if ESM group1 channel 7 is flagged
	{
		// NHET1 RAM parity error was not flagged to ESM.
		// Need custom routine to handle this failure instead of the infinite loop.
		while(1);
	}
	else
	{
		esmREG->ESTATUS1[0] = 0x80;			// clear ESM group1 channel 7 flag
	}
}
void htu1ParityCheck(void)
{
	volatile unsigned int hturead = 0;

	htuREG1->PCR = 0x0000010A;				// Enable parity and TEST mode
	HTU1PARLOC ^= 0x1;						// flip parity bit
	htuREG1->PCR = 0x0000000A;				// Disable parity RAM test mode

	hturead = HTU1RAMLOC;					// read to cause parity error

	if (!(esmREG->ESTATUS1[0] & 0x100))		// check if ESM group1 channel 8 is flagged
	{
		// HTU1 RAM parity error was not flagged to ESM.
		// Need custom routine to handle this failure instead of the infinite loop.
		while(1);
	}
	else
	{
		htuREG1->PAR = 0x00010000;			// Clear HTU parity error flag
		esmREG->ESTATUS1[0] = 0x100;
	}
}
void nhet2parityCheck(void)
{
	volatile unsigned int nhetread = 0;

	nhetREG2->PCREG = 0x0000010A;			// Set TEST mode and enable parity checking
	NHET2RAMPARLOC ^= 0x1;					// flip parity bit
	nhetREG2->PCREG = 0x0000000A;			// Disable TEST mode

	nhetread = NHET2RAMLOC;					// read to cause parity error

	if (!(esmREG->ESTATUS1[0] & 0x80) && !(esmREG->ESTATUS4[0] & 0x4))		// check if ESM group1 channel 7 or 34 is flagged
	{
		// NHET2 RAM parity error was not flagged to ESM.
		// Need custom routine to handle this failure instead of the infinite loop.
		while(1);
	}
	else
	{
		esmREG->ESTATUS1[0] = 0x80;			// clear ESM group1 channel 7 flag
		esmREG->ESTATUS4[0] = 0x4;			// clear ESM group1 channel 34 flag
	}
}
void htu2ParityCheck(void)
{
	volatile unsigned int hturead = 0;

	htuREG2->PCR = 0x0000010A;				// Enable parity and TEST mode
	HTU2PARLOC ^= 0x1;						// flip parity bit
	htuREG2->PCR = 0x0000000A;				// Disable parity RAM test mode

	hturead = HTU2RAMLOC;					// read to cause parity error

	if (!(esmREG->ESTATUS1[0] & 0x100))		// check if ESM group1 channel 8 is flagged
	{
		// HTU2 RAM parity error was not flagged to ESM.
		// Need custom routine to handle this failure instead of the infinite loop.
		while(1);
	}
	else
	{
		htuREG2->PAR = 0x00010000;			// Clear HTU parity error flag
		esmREG->ESTATUS1[0] = 0x100;
	}
}

void adc1ParityCheck(void)
{
	volatile unsigned int adcramread = 0;

	mibadcREG1->PARCR = 0x10A;				// Set the TEST bit in the PARCR and enable parity checking
	ADC1RAMPAR = ~(ADC1RAMPAR);				// Invert the parity bits inside the ADC1 RAM's first location

	mibadcREG1->PARCR = 0x00A;				// clear the TEST bit

	adcramread = ADC1RAM;					// This read is expected to trigger a parity error

	if (!(esmREG->ESTATUS1[0] & 0x80000))	// Check for ESM group1 channel 19 to be flagged
	{
		// no ADC1 RAM parity error was flagged to ESM
		// Need custom routine to handle this failure instead of the infinite loop
		while(1);
	}
	else
	{
		esmREG->ESTATUS1[0] = 0x80000;		// clear ADC1 RAM parity error flag
	}
}
void adc2ParityCheck(void)
{
	volatile unsigned int adcramread = 0;

	mibadcREG2->PARCR = 0x10A;				// Set the TEST bit in the PARCR and enable parity checking
	ADC2RAMPAR = ~(ADC2RAMPAR);				// Invert the parity bits inside the ADC2 RAM's first location

	mibadcREG2->PARCR = 0x00A;				// clear the TEST bit

	adcramread = ADC2RAM;					// This read is expected to trigger a parity error

	if (!(esmREG->ESTATUS1[0] & 0x2))		// Check for ESM group1 channel 1 to be flagged
	{
		// no ADC2 RAM parity error was flagged to ESM
		// Need custom routine to handle this failure instead of the infinite loop
		while(1);
	}
	else
	{
		esmREG->ESTATUS1[0] = 0x2;			// clear ADC2 RAM parity error flag
	}
}
void dcan1ParityCheck(void)
{
	volatile unsigned int dcanread = 0;

	dcanREG1->CTL = 0x00001481;				// Disable parity, init mode, TEST mode
	dcanREG1->TEST = 0x00000200;			// Enable RAM Direct Access mode

	DCAN1RAMPAR ^= 0x00001000;				// flip the parity bit

	dcanREG1->CTL = 0x00002880;				// Enable parity, disable init, still TEST mode

	dcanread = DCAN1RAMLOC;					// Read location with parity error

	if (!(esmREG->ESTATUS1[0] & 0x00200000))	// check if ESM group1 channel 21 is flagged
	{
		// No DCAN1 RAM parity error was flagged to ESM
		// Need custom routine to handle this failure instead of the infinite loop
		while(1);
	}
	else
	{
		esmREG->ESTATUS1[0] = 0x00200000;	// clear ESM group1 channel 21 flag
		dcanREG1->CTL = 0x00002800;			// disable TEST mode
	}
}
void dcan2ParityCheck(void)
{
	volatile unsigned int dcanread = 0;

	dcanREG2->CTL = 0x00001481;				// Disable parity, init mode, TEST mode
	dcanREG2->TEST = 0x00000200;			// Enable RAM Direct Access mode

	DCAN2RAMPAR ^= 0x00001000;				// flip the parity bit

	dcanREG2->CTL = 0x00002880;				// Enable parity, disable init, still TEST mode

	dcanread = DCAN2RAMLOC;					// Read location with parity error

	if (!(esmREG->ESTATUS1[0] & 0x00800000))	// check if ESM group1 channel 23 is flagged
	{
		// No DCAN2 RAM parity error was flagged to ESM
		// Need custom routine to handle this failure instead of the infinite loop
		while(1);
	}
	else
	{
		esmREG->ESTATUS1[0] = 0x00800000;	// clear ESM group1 channel 23 flag
		dcanREG2->CTL = 0x00002800;			// disable TEST mode
	}
}
void dcan3ParityCheck(void)
{
	volatile unsigned int dcanread = 0;

	dcanREG3->CTL = 0x00001481;				// Disable parity, init mode, TEST mode
	dcanREG3->TEST = 0x00000200;			// Enable RAM Direct Access mode

	DCAN3RAMPAR ^= 0x00001000;				// flip the parity bit

	dcanREG3->CTL = 0x00002880;				// Enable parity, disable init, still TEST mode

	dcanread = DCAN3RAMLOC;					// Read location with parity error

	if (!(esmREG->ESTATUS1[0] & 0x00400000))	// check if ESM group1 channel 22 is flagged
	{
		// No DCAN3 RAM parity error was flagged to ESM
		// Need custom routine to handle this failure instead of the infinite loop
		while(1);
	}
	else
	{
		esmREG->ESTATUS1[0] = 0x00400000;	// clear ESM group1 channel 22 flag
		dcanREG3->CTL = 0x00002800;			// disable TEST mode
	}
}
void mibspi1ParityCheck(void)
{
	volatile unsigned int spiread = 0;

	mibspiREG1->MIBSPIE = 0x1;				// enable multi-buffered mode

	mibspiREG1->EDEN = 0xA;					// enable parity error detection
	mibspiREG1->PTESTEN = 1;				// enable parity test mode
	SPI1RAMPARLOC ^= 0x1;					// flip bit 0 of the parity location

	mibspiREG1->PTESTEN = 0;				// disable parity test mode

	spiread = SPI1RAMLOC;					// read from MibSPI1 RAM to cause parity error

	if (!(esmREG->ESTATUS1[0] & 0x20000))	// check if ESM group1 channel 17 is flagged
	{
		// No MibSPI1 RAM parity error was flagged to ESM.
		// Need custom routine to handle this failure instead of the infinite loop
		while(1);
	}
	else
	{
		mibspiREG1->UERRSTAT = 0x3;			// clear parity error flags
		esmREG->ESTATUS1[0] = 0x20000;		// clear ESM group1 channel 17 flag
	}
}
void mibspi3parityCheck(void)
{
	volatile unsigned int spiread = 0;

	mibspiREG3->MIBSPIE = 0x1;				// enable multi-buffered mode

	mibspiREG3->PTESTEN = 1;				// enable parity test mode
	SPI3RAMPARLOC ^= 0x1;					// flip bit 0 of the parity location

	mibspiREG3->EDEN = 0xA;					// enable parity error detection
	mibspiREG3->PTESTEN = 0;				// disable parity test mode

	spiread = SPI3RAMLOC;					// read from MibSPI3 RAM to cause parity error

	if (!(esmREG->ESTATUS1[0] & 0x40000))	// check if ESM group1 channel 18 is flagged
	{
		// No MibSPI3 RAM parity error was flagged to ESM.
		// Need custom routine to handle this failure instead of the infinite loop
		while(1);
	}
	else
	{
		mibspiREG3->UERRSTAT = 0x3;			// clear parity error flags
		esmREG->ESTATUS1[0] = 0x40000;		// clear ESM group1 channel 18 flag
	}
}
void mibspi5ParityCheck(void)
{
	volatile unsigned int spiread = 0;

	mibspiREG5->MIBSPIE = 0x1;				// enable multi-buffered mode

	mibspiREG5->PTESTEN = 1;				// enable parity test mode
	SPI5RAMPARLOC ^= 0x1;					// flip bit 0 of the parity location

	mibspiREG5->EDEN = 0xA;					// enable parity error detection
	mibspiREG5->PTESTEN = 0;				// disable parity test mode

	spiread = SPI5RAMLOC;					// read from MibSPI5 RAM to cause parity error

	if (!(esmREG->ESTATUS1[0] & 0x01000000))	// check if ESM group1 channel 24 is flagged
	{
		// No MibSPI5 RAM parity error was flagged to ESM.
		// Need custom routine to handle this failure instead of the infinite loop
		while(1);
	}
	else
	{
		mibspiREG5->UERRSTAT = 0x3;			// clear parity error flags
		esmREG->ESTATUS1[0] = 0x01000000;		// clear ESM group1 channel 24 flag
	}
}

void custom_dabort(void)
{
	/* Need custom data abort handler here.
	 * This data abort is not caused due to diagnostic checks of flash and TCRAM ECC logic.
	 */
}

void stcSelfCheckFail(void)
{
	/* CPU self-test controller's own self-test failed.
	 * It is not possible to verify that STC is capable of indicating a CPU self-test error.
	 * It is not recommended to continue operation.
	 */
	while(1);
}

void cpuSelfTestFail(void)
{
	/* CPU self-test has failed.
	 * CPU operation is not reliable.
	 */
	while(1);
}

/* USER CODE END */

/* Function: _c_int00()
 * This CPU branches to this function from the reset vector at address 0x00000000.
 * This function is executed upon every CPU reset.
 */

#pragma INTERRUPT(_c_int00, RESET)

void _c_int00()
{

/* USER CODE BEGIN (5) */
/* USER CODE END */

    /* Enable VFP Unit */
    _coreEnableVfp_();

    /* Initialize Core Registers, including stack pointers for all modes */
    _coreInitRegisters_();

    /* Implement work-around for CCM-R4 issue on silicon revision A */
    if (systemREG1->DEV == 0x802AAD05)
    {
        _esmCcmErrorsClear_();
    }

    /* Enable response to ECC errors indicated by CPU for accesses to flash */
    flashWREG->FEDACCTRL1 = 0x000A060A;

	/* Enable CPU Event Export */
    /* This allows the CPU to signal any single-bit or double-bit errors detected
     * by its ECC logic for accesses to program flash or data RAM.
     */
    asm("	mrc   p15, #0x00, r0,         c9, c12, #0x00");
    asm("	orr   r0,  r0,    #0x10");
    asm("	mcr   p15, #0x00, r0,         c9, c12, #0x00");
    asm("	mrc   p15, #0x00, r0,         c9, c12, #0x00");

    /* Enable CPU ECC checking for ATCM (flash accesses) */
    asm("	mrc   p15, #0x00, r0,         c1, c0,  #0x01");
    asm("	orr   r0,  r0,    #0x1<<25");
    asm("	dmb");
    asm("	mcr   p15, #0x00, r0,         c1, c0,  #0x01");
    asm("	isb");

/* USER CODE BEGIN (6) */
/* USER CODE END */

    /* Reset handler: the following instructions read from the system exception status register
     * to identify the cause of the CPU reset.
     */

    /* check for power-on reset condition */
	if (systemREG1->SYSESR & 0x8000)
	{
		/* clear all reset status flags */
		systemREG1->SYSESR = 0xFFFF;

/* USER CODE BEGIN (7) */
/* USER CODE END */

		/* continue with normal start-up sequence */
	}
	else if (systemREG1->SYSESR & 0x4000)
	{
		/* Reset caused due to oscillator failure.
		Add user code here to handle oscillator failure */

/* USER CODE BEGIN (8) */
		while(1);
/* USER CODE END */
	}
	else if (systemREG1->SYSESR & 0x2000)
	{
		/* Reset caused due to windowed watchdog violation.
		Add user code here to handle watchdog violation */

/* USER CODE BEGIN (9) */
		while(1);
/* USER CODE END */
	}
	else if (systemREG1->SYSESR & 0x20)
	{
		/* Reset caused due to CPU reset.
		CPU reset can be caused by CPU self-test completion, or
		by toggling the "CPU RESET" bit of the CPU Reset Control Register. */

/* USER CODE BEGIN (10) */

		/* reset could be caused by stcSelfCheck run or by an actual CPU self-test run */
		
		if ((stcREG->STCSCSCR & 0xF) == 0xA)			// check if this was an stcSelfCheck run
		{
			/* check if the self-test fail bit is set */
			if ((stcREG->STCGSTAT & 0x3) != 0x3)
			{
				stcSelfCheckFail();						// STC self-check has failed
			}
			else										// STC self-check has passed
			{
				stcREG->STCSCSCR = 0x05;				// clear self-check mode
				stcREG->STCGSTAT = 0x3;					// clear STC global status flags
				esmREG->ESTATUS1[0] = 0x08000000;		// clear ESM group1 channel 27 status flag
				cpuSelfTest();							// Start CPU Self-Test
			}
		}
		else if ((stcREG->STCGSTAT & 0x1) == 0x1)		// CPU reset caused by CPU self-test completion
		{
			if ((stcREG->STCGSTAT & 0x2) == 0x2)		// Self-Test Fail flag is set
			{
				cpuSelfTestFail();						// Call CPU self-test failure handler
			}
			else										// CPU self-test completed successfully
			{
				afterSTC();								// Continue start-up sequence after CPU STC completed
			}
		}
		else											// CPU reset caused by software writing to CPU RESET bit
		{
			/* Add custom routine here to handle the case where software causes CPU reset */
		}
	} 
		
/* USER CODE END */
	
	else if (systemREG1->SYSESR & 0x10)
	{
		/* Reset caused due to software reset.
		Add user code to handle software reset. */

/* USER CODE BEGIN (11) */
		while(1);
/* USER CODE END */
	}
	else
	{
		/* Reset caused by nRST being driven low externally.
		Add user code to handle external reset. */

/* USER CODE BEGIN (12) */
		while(1);
/* USER CODE END */
	}

	/* Check if there were ESM group3 errors during power-up.
	 * These could occur during eFuse auto-load or during reads from flash OTP
	 * during power-up. Device operation is not reliable and not recommended
	 * in this case.
	 * An ESM group3 error only drives the nERROR pin low. An external circuit
	 * that monitors the nERROR pin must take the appropriate action to ensure that
	 * the system is placed in a safe state, as determined by the application.
	 */
	if (esmREG->ESTATUS1[2])
	{
		while(1);
	}
	else
	{
		/* Configure PLL control registers and enable PLLs.
		 * The PLL takes (127 + 1024 * NR) oscillator cycles to acquire lock.
		 * This initialization sequence performs all the tasks that are not
		 * required to be done at full application speed while the PLL locks.
		 */
		setupPLL();

		/* Run eFuse controller start-up checks and start eFuse controller ECC self-test.
		 * This includes a check for the eFuse controller error outputs to be stuck-at-zero.
		 */
		efcCheck();

		/* Enable clocks to peripherals and release peripheral reset */
		periphInit();

		/* Configure device-level multiplexing and I/O multiplexing */
		muxInit();

		/* Wait for eFuse controller self-test to complete and check results */
		if (!checkEFCSelfTest())							// eFuse controller ECC logic self-test failed
		{
			efcClass2Error();								// device operation is not reliable
		}

		/* Set up flash address and data wait states based on the target CPU clock frequency
		 * The number of address and data wait states for the target CPU clock frequency are specified
		 * in the specific part's datasheet.
		 */
		setupFlash();

		/* Configure the LPO such that HF LPO is as close to 10MHz as possible */
		trimLPO();

		/* Check if there was an ESM error from FMC OTP read during power-up */
		fmcBus2Check();

		/* Wait for PLLs to start up and map clock domains to desired clock sources */
		mapClocks();

		/* Output VCLK on ECLK */
		systemREG1->SYSPC1 = 0x1;				// ECLK is functional pin
		systemREG1->ECPCNTL = 0x00800000;		// ECLK output continues even when CPU is halted in debug mode.

		/* Make sure that the CPU self-test controller can actually detect a fault inside CPU */
		stcSelfCheck();
	}
}

void afterSTC(void)
{
	/* Make sure that CCM-R4F is working as expected.
	 * This function puts the CCM-R4F module through its self-test modes.
	 * It ensures that the CCM-R4F is indeed capable of detecting a CPU mismatch,
	 * and is also capable of indicating a mismatch error to the ESM.
	 */
	ccmSelfCheck();

	/* Run a diagnostic check on the memory self-test controller.
	 * This function chooses a RAM test algorithm and runs it on an on-chip ROM.
	 * The memory self-test is expected to fail. The function ensures that the PBIST controller
	 * is capable of detecting and indicating a memory self-test failure.
	 */
	pbistSelfCheck();

	/* Run PBIST on CPU RAM.
	 * The PBIST controller needs to be configured separately for single-port and dual-port SRAMs.
	 * The CPU RAM is a single-port memory. The actual "RAM Group" for all on-chip SRAMs is defined in the
	 * device datasheet. The first 64kB of CPU RAM is RAM Group # 6, which requires bit 5 to be set,
	 * hence the value 0x20 being passed to the function.
	 */
	pbistRun(0x20, SP_RAMs);

	/* Wait for PBIST for CPU RAM to be completed */
	while (!(systemREG1->MSTCGSTAT & 0x1));

	// Check if CPU RAM passed the self-test
	if (pbistREG->FSRF0 || pbistREG->FSRF1)
	{
		/* CPU RAM failed the self-test.
		 * Need custom handler to check the memory failure
		 * and to take the appropriate next step.
		 */
		while(1);
	}

	/* Disable PBIST clocks and disable memory self-test mode */
	pbistStop();

	/* Initialize CPU RAM.
	 * This function uses the system module's hardware for auto-initialization of memories and their
	 * associated protection schemes. The CPU RAM is initialized by setting bit 0 of the MSIENA register.
	 * Hence the value 0x1 passed to the function.
	 * This function will initialize the entire CPU RAM and the corresponding ECC locations.
	 */
	_memoryInit_(0x1);

	/* Enable ECC checking for TCRAM accesses.
	 * This function enables the CPU's ECC logic for accesses to B0TCM and B1TCM.
	 */
	_coreEnableRamEcc_();

	/* Start PBIST on all dual-port memories */
	if (IOMM_BOOT_REG)
	{
		pbistRun(DP_RAM_GRPS_TMS, DP_RAMs);
	}
	else
	{
		pbistRun(DP_RAM_GRPS_RM, DP_RAMs);
	}

	/* Test the CPU ECC mechanism for RAM accesses.
	 * The checkBxRAMECC functions cause deliberate single-bit and double-bit errors in TCRAM accesses
	 * by corrupting 1 or 2 bits in the ECC. Reading from the TCRAM location with a 2-bit error
	 * in the ECC causes a data abort exception. The data abort handler is written to look for
	 * deliberately caused exception and to return the code execution to the instruction
	 * following the one that caused the abort.
	 */
	checkB0RAMECC();
	tcram1REG->RAMCTRL &= ~(0x00000100);				// disable writes to ECC RAM
	tcram2REG->RAMCTRL &= ~(0x00000100);

	checkB1RAMECC();
	tcram1REG->RAMCTRL &= ~(0x00000100);				// disable writes to ECC RAM
	tcram2REG->RAMCTRL &= ~(0x00000100);

	/* Test the CPU ECC mechanism for Flash accesses.
	 * The checkFlashECC function uses the flash interface module's diagnostic mode 7
	 * to create single-bit and double-bit errors in CPU accesses to the flash. A double-bit
	 * error on reading from flash causes a data abort exception.
	 * The data abort handler is written to look for deliberately caused exception and
	 * to return the code execution to the instruction following the one that was aborted.
	 *
	 */
	checkFlashECC();
	flashWREG->FDIAGCTRL = 0x000A0007;					// disable flash diagnostic mode

	/* Check whether the PBIST for all dual-port RAMs has completed */
	while (!(systemREG1->MSTCGSTAT & 0x1));				// Wait for Memory Self-test Done bit to be set

	// Check if all memories passed the self-test
	if (pbistREG->FSRF0 || pbistREG->FSRF1)
	{
		/* At least one memory failed the self-test.
		 * Need custom handler to check the memory failure
		 * and to take the appropriate next step.
		 */
		while(1);
	}
	else
	{
		/* Disable memory self-test mode */
		pbistStop();

		/* All dual-port memories passed self-test.
		 * Need to now test the single-port RAMs excluding the first 64kB of CPU RAM
		 * since that chunk was tested before and passed.
		 */
		if (IOMM_BOOT_REG)
		{
			pbistRun(SP_RAM_GRPS_TMS & ~(0x20), SP_RAMs);
		}
		else
		{
			pbistRun(SP_RAM_GRPS_RM & ~(0x20), SP_RAMs);
		}

		while (!(systemREG1->MSTCGSTAT & 0x1));				// Wait for Memory Self-test Done bit to be set
		if (pbistREG->FSRF0 || pbistREG->FSRF1)
		{
			/* At least one memory failed the self-test.
			 * Need custom handler to check the memory failure
			 * and to take the appropriate next step.
			 */
			while(1);
		}
		pbistStop();
	}

	/* Release the MibSPIx modules from local reset.
	 * This will cause the MibSPIx RAMs to get initialized along with the parity memory.
	 */
	mibspiREG1->GCR0 = 0x1;
	mibspiREG3->GCR0 = 0x1;
	mibspiREG5->GCR0 = 0x1;

    /* Initialize all on-chip SRAMs except for MibSPIx RAMs
     * The MibSPIx modules have their own auto-initialization mechanism which is triggered
     * as soon as the modules are brought out of local reset.
     */
	/* The system module auto-init will hang on the MibSPI RAM if the module is still in local reset.
	 */

	if (IOMM_BOOT_REG)
	{
		_memoryInit_(RAM_INIT_MASK_TMS);
	}
	else
	{
		_memoryInit_(RAM_INIT_MASK_RM);
	}

	/* Test the parity protection mechanism for peripheral RAMs
	 * The following memories have parity protection that needs to be checked:
	 * VIM, DMA, ADC1, ADC2, NHET1, NHET2, HTU1, HTU2, FlexRay, FTU,
	 * MibSPI1, MibSPI3, MibSPI5, DCAN1, DCAN2, DCAN3
	 */
	nhet1ParityCheck();
	htu1ParityCheck();
	nhet2parityCheck();
	htu2ParityCheck();
	adc1ParityCheck();
	adc2ParityCheck();
	dcan1ParityCheck();
	dcan2ParityCheck();
	dcan3ParityCheck();
	vimParityCheck();
	dmaParityCheck();

	/* Wait for MibSPIx memory initialization to complete */
	while (mibspiREG1->BUFINIT);		// wait for MibSPI1 RAM to complete initialization
	while (mibspiREG3->BUFINIT);		// wait for MibSPI1 RAM to complete initialization
	while (mibspiREG5->BUFINIT);		// wait for MibSPI1 RAM to complete initialization

	mibspi1ParityCheck();
	mibspi3parityCheck();
	mibspi5ParityCheck();

	/* Enable IRQ offset via the CPU's VIC port */
    _coreEnableIrqVicOffset_();

    /* Initialize VIM table */
    {
        uint32_t i;

        for (i = 0; i < 90U; i++)
        {
            vimRAM->ISR[i] = s_vim_init[i];
        }
    }

    /* set IRQ/FIQ priorities for each interrupt request*/
    vimREG->FIRQPR0 =  SYS_FIQ
                    | (SYS_FIQ <<  1U)
                    | (SYS_IRQ <<  2U)
                    | (SYS_IRQ <<  3U)
                    | (SYS_IRQ <<  4U)
                    | (SYS_IRQ <<  5U)
                    | (SYS_IRQ <<  6U)
                    | (SYS_IRQ <<  7U)
                    | (SYS_IRQ <<  8U)
                    | (SYS_IRQ <<  9U)
                    | (SYS_IRQ << 10U)
                    | (SYS_IRQ << 11U)
                    | (SYS_IRQ << 12U)
                    | (SYS_IRQ << 13U)
                    | (SYS_IRQ << 14U)
                    | (SYS_IRQ << 15U)
                    | (SYS_IRQ << 16U)
                    | (SYS_IRQ << 17U)
                    | (SYS_IRQ << 18U)
                    | (SYS_IRQ << 19U)
                    | (SYS_IRQ << 20U)
                    | (SYS_IRQ << 21U)
                    | (SYS_IRQ << 22U)
                    | (SYS_IRQ << 23U)
                    | (SYS_IRQ << 24U)
                    | (SYS_IRQ << 25U)
                    | (SYS_IRQ << 26U)
                    | (SYS_IRQ << 27U)
                    | (SYS_IRQ << 28U)
                    | (SYS_IRQ << 29U)
                    | (SYS_IRQ << 30U)
                    | (SYS_IRQ << 31U);

    vimREG->FIRQPR1 =  SYS_IRQ
                    | (SYS_IRQ <<  1U)
                    | (SYS_IRQ <<  2U)
                    | (SYS_IRQ <<  3U)
                    | (SYS_IRQ <<  4U)
                    | (SYS_IRQ <<  5U)
                    | (SYS_IRQ <<  6U)
                    | (SYS_IRQ <<  7U)
                    | (SYS_IRQ <<  8U)
                    | (SYS_IRQ <<  9U)
                    | (SYS_IRQ << 10U)
                    | (SYS_IRQ << 11U)
                    | (SYS_IRQ << 12U)
                    | (SYS_IRQ << 13U)
                    | (SYS_IRQ << 14U)
                    | (SYS_IRQ << 15U)
                    | (SYS_IRQ << 16U)
                    | (SYS_IRQ << 17U)
                    | (SYS_IRQ << 18U)
                    | (SYS_IRQ << 19U)
                    | (SYS_IRQ << 20U)
                    | (SYS_IRQ << 21U)
                    | (SYS_IRQ << 22U)
                    | (SYS_IRQ << 23U)
                    | (SYS_IRQ << 24U)
                    | (SYS_IRQ << 25U)
                    | (SYS_IRQ << 26U)
                    | (SYS_IRQ << 27U)
                    | (SYS_IRQ << 28U)
                    | (SYS_IRQ << 29U)
                    | (SYS_IRQ << 30U)
                    | (SYS_IRQ << 31U);


    vimREG->FIRQPR2 =  SYS_IRQ
                    | (SYS_IRQ << 1U)
                    | (SYS_IRQ << 2U)
                    | (SYS_IRQ << 3U)
                    | (SYS_IRQ << 4U)
                    | (SYS_IRQ << 5U)
                    | (SYS_IRQ << 6U)
                    | (SYS_IRQ << 7U)
                    | (SYS_IRQ << 8U)
                    | (SYS_IRQ << 9U)
                    | (SYS_IRQ << 10U)
                    | (SYS_IRQ << 11U)
                    | (SYS_IRQ << 12U)
                    | (SYS_IRQ << 13U)
                    | (SYS_IRQ << 14U)
                    | (SYS_IRQ << 15U)
                    | (SYS_IRQ << 16U)
                    | (SYS_IRQ << 17U)
                    | (SYS_IRQ << 18U)
                    | (SYS_IRQ << 19U)
                    | (SYS_IRQ << 20U)
                    | (SYS_IRQ << 21U)
                    | (SYS_IRQ << 22U)
                    | (SYS_IRQ << 23U)
                    | (SYS_IRQ << 24U)
                    | (SYS_IRQ << 25U);


    /* enable desired interrupts */
    vimREG->REQMASKSET0 = 1U
                        | (1U << 1U)
                        | (1U << 2U)		// RTI compare 0 interrupt
                        | (0U << 3U)
                        | (0U << 4U)
                        | (0U << 5U)
                        | (0U << 6U)
                        | (0U << 7U)
                        | (0U << 8U)
                        | (0U << 9U)
                        | (0U << 10U)
                        | (0U << 11U)
                        | (0U << 12U)
                        | (0U << 13U)
                        | (0U << 14U)
                        | (0U << 15U)
                        | (0U << 16U)
                        | (0U << 17U)
                        | (0U << 18U)
                        | (0U << 19U)
                        | (0U << 20U)
                        | (0U << 21U)
                        | (0U << 22U)
                        | (0U << 23U)
                        | (0U << 24U)
                        | (0U << 25U)
                        | (0U << 26U)
                        | (0U << 27U)
                        | (0U << 28U)
                        | (0U << 29U)
                        | (0U << 30U)
                        | (0U << 31U);

    vimREG->REQMASKSET1 = 0U
                        | (0U << 1U)
                        | (0U << 2U)
                        | (0U << 3U)
                        | (0U << 4U)
                        | (0U << 5U)
                        | (0U << 6U)
                        | (0U << 7U)
                        | (0U << 8U)
                        | (0U << 9U)
                        | (0U << 10U)
                        | (0U << 11U)
                        | (0U << 12U)
                        | (0U << 13U)
                        | (0U << 14U)
                        | (0U << 15U)
                        | (0U << 16U)
                        | (0U << 17U)
                        | (0U << 18U)
                        | (0U << 19U)
                        | (0U << 20U)
                        | (0U << 21U)
                        | (0U << 22U)
                        | (0U << 23U)
                        | (0U << 24U)
                        | (0U << 25U)
                        | (0U << 26U)
                        | (0U << 27U)
                        | (0U << 28U)
                        | (0U << 29U)
                        | (0U << 30U)
                        | (0U << 31U);

    vimREG->REQMASKSET2 = 0U
                        | (0U << 1U)
                        | (0U << 2U)
                        | (0U << 3U)
                        | (0U << 4U)
                        | (0U << 5U)
                        | (0U << 6U)
                        | (0U << 7U)
                        | (0U << 8U)
                        | (0U << 9U)
                        | (0U << 10U)
                        | (0U << 11U)
                        | (0U << 12U)
                        | (0U << 13U)
                        | (0U << 14U)
                        | (0U << 15U)
                        | (0U << 16U)
                        | (0U << 17U)
                        | (0U << 18U)
                        | (0U << 19U)
                        | (0U << 20U)
                        | (0U << 21U)
                        | (0U << 22U)
                        | (0U << 23U)
                        | (0U << 24U)
                        | (0U << 25U);

	/* Configure system response to error conditions signaled to the ESM group1 */
	/* This function can be configured from the ESM tab of HALCoGen */
	esmInit();


/* Compiler-specific initializations.
 * The below routines are required for TI CodeGen tools.
 */

    /* initalise copy table */
    if ((uint32_t *)&__binit__ != (uint32_t *)0xFFFFFFFFU)
    {
        extern void copy_in(void *binit);
        copy_in((void *)&__binit__);
    }

    /* initalise the C global variables */
    if (&__TI_Handler_Table_Base < &__TI_Handler_Table_Limit)
    {
        uint8_t **tablePtr   = (uint8_t **)&__TI_CINIT_Base;
        uint8_t **tableLimit = (uint8_t **)&__TI_CINIT_Limit;

        while (tablePtr < tableLimit)
        {
            uint8_t *loadAdr = *tablePtr++;
            uint8_t *runAdr  = *tablePtr++;
            uint8_t  idx     = *loadAdr++;
            handler_fptr   handler = (handler_fptr)(&__TI_Handler_Table_Base)[idx];

            (*handler)((const uint8_t *)loadAdr, runAdr);
        }
    }

    /* Initialize constructors */
    if (__TI_PINIT_Base < __TI_PINIT_Limit)
    {
        void (**p0)() = (void *)__TI_PINIT_Base;

        while ((uint32_t)p0 < __TI_PINIT_Limit)
        {
            void (*p)() = *p0++;
            p();
        }
    }

/* USER CODE BEGIN (13) */

    /* Configure other safety features here.
     *
     * - Check that DCC can actually indicate an error.
     * - Configure DCC to monitor PLL output.
     * - Test that all bus master MPU permission violations are flagged to ESM.
     * - Run a background check on entire flash using CRC.
     * -
     * - Peripheral initialization
     * 	   - Calibrate the ADC for offset errors and calculate the correction factor.
     * 	   - Run a self-test on all ADC inputs.
     * 	   - Check I/O loop-back on all peripherals.
     *
     * - Configure the Memory Protection Unit for all bus masters.
     * - Configure the digital windowed watch-dog.
     * - Configure the RTI to generate periodic interrupts as required.
     * - Configure the N2HET1-to-N2HET2 monitoring capability.
     * - Configure desired access permissions to peripherals using PCR registers.
     * - Configure external safety companion, e.g. TI TPS6538x, for online diagnostic operation.
     *
     */

/* USER CODE END */

    /* call the main application.
     * The CPU can be switched to user mode now, if so desired.
     */
    main();
    exit();
}


/* USER CODE BEGIN (14) */

void dcanErrorNotification(dcanBASE_t *x, uint32_t y)
{

}

void dcanMessageNotification(dcanBASE_t *x, uint32_t y)
{

}

void dccNotification(void)
{

}

void edgeNotification(nhetBASE_t *x, uint32_t y)
{

}

void esmGroup1Notification(uint32_t x)
{

}

void esmGroup2Notification(uint32_t x)
{

}

void gioNotification(int x)
{

}

void i2cNotification(void)
{

}

void linNotification(void)
{

}

void mibadcNotification(mibadcBASE_t *x, uint32_t y)
{

}

void mibspiGroupNotification(mibspiBASE_t *x, uint32_t y)
{

}

void mibspiNotification(mibspiBASE_t *x, uint32_t y)
{

}

void pwmNotification(nhetBASE_t *x, uint32_t y, uint32_t z)
{

}

void rtiNotification(unsigned int x)
{
	/* Toggle HET pin 0 */
    gioSetPort(nhetPORT1, gioGetPort(nhetPORT1) ^ 0x00000001);

}

void sciNotification(void)
{

}

void spiNotification(void)
{

}


/* USER CODE END */
