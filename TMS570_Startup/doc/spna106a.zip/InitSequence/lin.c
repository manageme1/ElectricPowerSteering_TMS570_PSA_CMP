/** @file lin.c 
*   @brief LIN Driver Inmplmentation File
*   @date 04.October.2011
*   @version 1.02.000
*
*/

/* (c) Texas Instruments 2009-2011, All rights reserved. */

/* USER CODE BEGIN (0) */
/* USER CODE END */

#include "lin.h"

/* USER CODE BEGIN (1) */
/* USER CODE END */

/** @fn void linInit(void)
*   @brief Initializes the lin Driver
*
*   This function initializes the lin module.
*/
void linInit(void)
{
/* USER CODE BEGIN (2) */
/* USER CODE END */
    /** @b intalise @b LIN */

    /** - Release from reset */
    linREG->GCR0 = 1U;

    /** - Setup control register 1
    *     - Enable transmitter
    *     - Enable receiver
    *     - Stop when debug mode is entered
    *     - Disable Loopback mode
    *     - Mask filtering with ID-Byte
    *     - Use enhance checksum
    *     - Enable multi buffer mode
    *     - Disable automatic baudrate adjustment
    *     - Disable sleep mode
    *     - Keep state machine in software reset
    *     - Enter LIN mode
    *     - Set LIN module as master
    *     - Enable/Disable parity
    *     - Disable data length control in ID4 and ID5
    */
    linREG->GCR1 = 0x03000C60U | 0U;

    /** - Setup maximum baud rate prescaler */
    linREG->MBRSR = 4046U;

    /** - Setup baud rate prescaler */
    linREG->BRSR = 280U;

    /** - Setup RX and TX reception masks */
    linREG->MASK = (0x00U << 16U) | 0x00U;

    /** - Setup compare
    *     - Sync delimiter
    *     - Sync break extension
    */
    linREG->COMP = ((1U - 1U) << 8U) | (13U - 13U);

    /** - Setup response length */
    linREG->LENGTH = (8U - 1U);

    /** - Set LIN pins functional mode 
    *     - TX
    *     - RX
    *     - CLK
    */
    linREG->FUN = 4U | 2U | 0U;

    /** - Set LIN pins default output value
    *     - TX
    *     - RX
    *     - CLK
    */
    linREG->DOUT = 0U | 0U | 0U;

    /** - Set LIN pins output direction
    *     - TX
    *     - RX
    *     - CLK
    */
    linREG->DIR = 0U | 0U | 0U;

    /** - Set LIN pins open drain enable
    *     - TX
    *     - RX
    *     - CLK
    */
    linREG->ODR = 0U | 0U | 0U;

    /** - Set LIN pins pullup/pulldown enable
    *     - TX
    *     - RX
    *     - CLK
    */
    linREG->PD = 0U | 0U | 0U;

    /** - Set LIN pins pullup/pulldown select
    *     - TX
    *     - RX
    *     - CLK
    */
    linREG->PSL = 4U | 2U | 1U;

    /** - Set interrupt level 
    *     - Bit error level
    *     - Physical bus error level
    *     - Checksum error level
    *     - Inconsistent sync field error level
    *     - No response error level
    *     - Framing error level
    *     - Overrun error level
    *     - Parity error level
    *     - Identifier level
    *     - RX level
    *     - TX level
    *     - Timeout after 3 wakeup signals level
    *     - Timeout after wakeup signal level
    *     - Timeout level
    *     - Wakeup level
    *     - Break detect level
    */
    linREG->SETINTLVL = 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U
                       | 0x00000000U;

    /** - Set interrupt enable 
    *     - Enable/Disable bit error
    *     - Enable/Disable physical bus error level
    *     - Enable/Disable checksum error level
    *     - Enable/Disable inconsistent sync field error level
    *     - Enable/Disable no response error level
    *     - Enable/Disable framing error level
    *     - Enable/Disable overrun error level
    *     - Enable/Disable parity error level
    *     - Enable/Disable identifier level
    *     - Enable/Disable RX level
    *     - Enable/Disable TX level
    *     - Enable/Disable timeout after 3 wakeup signals level
    *     - Enable/Disable timeout after wakeup signal level
    *     - Enable/Disable timeout level
    *     - Enable/Disable wakeup level
    *     - Enable/Disable break detect level
    */
    linREG->SETINT = 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U
                    | 0x00000000U;

    /** - Finaly start LIN */
    linREG->GCR1 |= 0x00000080U;

/* USER CODE BEGIN (3) */
/* USER CODE END */
}


/** @fn void linSetFunctional(linBASE_t *lin, uint32_t port)
*   @brief Change functional behavoiur of pins at runtime.
*   @param[in] lin   - lin module base address
*   @param[in] port  - Value to write to FUN register
*
*   Change the value of the PCFUN register at runtime, this allows to
*   dynaimcaly change the functionality of the LIN pins between functional
*   and GIO mode.
*/
void linSetFunctional(linBASE_t *lin, uint32_t port)
{
/* USER CODE BEGIN (4) */
/* USER CODE END */

    lin->FUN = port;

/* USER CODE BEGIN (5) */
/* USER CODE END */
}


/** @fn void linSendHeader(linBASE_t *lin, uint8_t identifier)
*   @brief Send lin header.
*   @param[in] lin  - lin module base address
*   @param[in] identifier - lin header id
*
*   Send lin header including sync break field, sync field and identifier.
*/
void linSendHeader(linBASE_t *lin, uint8_t identifier)
{
/* USER CODE BEGIN (6) */
/* USER CODE END */

    lin->IDBYTE = identifier;

/* USER CODE BEGIN (7) */
/* USER CODE END */
}


/** @fn void linSendWakupSignal(linBASE_t *lin)
*   @brief Send lin wakeup signal.
*   @param[in] lin  - lin module base address
*
*   Send lin wakeup signal to terminate the sleep mode of any lin node connected to the BUS.
*/
void linSendWakupSignal(linBASE_t *lin)
{
/* USER CODE BEGIN (8) */
/* USER CODE END */

    lin->TDx[0] = 0x80;
    lin->GCR2   = 0x00000100U;

/* USER CODE BEGIN (9) */
/* USER CODE END */
}


/** @fn void linSoftwareReset(linBASE_t *lin)
*   @brief Perform sofware reset.
*   @param[in] lin  - lin module base address
*
*   Perform software reset of lin module.
*   This function will reset the lin state machine and clear all pending flags.
*   It is required to call this function after a wakeup signal has been sent.
*/
void linSoftwareReset(linBASE_t *lin)
{
/* USER CODE BEGIN (10) */
/* USER CODE END */

    lin->GCR2 &= ~0x00000080U;
    lin->GCR2 |=  0x00000080U;

/* USER CODE BEGIN (11) */
/* USER CODE END */
}

/** @fn uint32_t linIsTxReady(linBASE_t *lin)
*   @brief Check if Tx buffer empty
*   @param[in] lin - lin module base address
*
*   @return The TX ready flag
*
*   Checks to see if the Tx buffer ready flag is set, returns
*   0 is flags not set otherwise will return the Tx flag itself.
*/
uint32_t linIsTxReady(linBASE_t *lin)
{
/* USER CODE BEGIN (12) */
/* USER CODE END */

    return lin->FLR & LIN_TX_READY;
}

/** @fn void linSetLength(linBASE_t *lin, uint32_t length)
*   @brief Send Data
*   @param[in] lin    - lin module base address
*   @param[in] length - number of data words in bytes. Range: 1-8.
*
*   Send data response length in bytes. 
*/
void linSetLength(linBASE_t *lin, uint32_t length)
{
/* USER CODE BEGIN (13) */
/* USER CODE END */

    lin->LENGTH = length - 1U;

/* USER CODE BEGIN (14) */
/* USER CODE END */
}

/** @fn void linSend(linBASE_t *lin, const uint8_t *data)
*   @brief Send Data
*   @param[in] lin    - lin module base address
*   @param[in] data   - pointer to data to send
*
*   Send a block of data pointed to by 'data'.
*   The number of data to transmit must be set with 'linSetLength' before. 
*/
void linSend(linBASE_t *lin, const uint8_t *data)
{
    int           i;
    int           length = lin->LENGTH;
    uint8_t *pData = (uint8_t *)data + length;

/* USER CODE BEGIN (15) */
/* USER CODE END */

    for (i = length; i >= 0; i--)
    {
        lin->TDx[i] = *pData--;
    }

/* USER CODE BEGIN (16) */
/* USER CODE END */
}

/** @fn uint32_t linIsRxReady(linBASE_t *lin)
*   @brief Check if Rx buffer full
*   @param[in] lin - lin module base address
*
*   @return The Rx ready flag
*
*   Checks to see if the Rx buffer full flag is set, returns
*   0 is flags not set otherwise will return the Rx flag itself.
*/
uint32_t linIsRxReady(linBASE_t *lin)
{
/* USER CODE BEGIN (17) */
/* USER CODE END */

    return lin->FLR & LIN_RX_INT;
}


/** @fn uint32_t linTxRxError(linBASE_t *lin)
*   @brief Return Tx and Rx Error flags
*   @param[in] lin - lin module base address
*
*   @return The Tx and Rx error flags
*
*   Returns the bit, physical bus, checksum, inconsisten sync field,
*   no response, framing, overun, parity and timeout error flags.
*   It also clears the error flags before returning.
*/
uint32_t linTxRxError(linBASE_t *lin)
{
    uint32_t status = lin->FLR & (LIN_BE_INT 
                    | LIN_PBE_INT 
                    | LIN_CE_INT 
                    | LIN_ISFE_INT 
                    | LIN_NRE_INT 
                    | LIN_FE_INT 
                    | LIN_OE_INT 
                    | LIN_PE_INT     
                    | LIN_TOA3WUS_INT 
                    | LIN_TOAWUS_INT 
                    | LIN_TO_INT);

    lin->FLR = LIN_BE_INT 
             | LIN_PBE_INT 
             | LIN_CE_INT 
             | LIN_ISFE_INT 
             | LIN_NRE_INT 
             | LIN_FE_INT 
             | LIN_OE_INT 
             | LIN_PE_INT     
             | LIN_TOA3WUS_INT 
             | LIN_TOAWUS_INT 
             | LIN_TO_INT;

/* USER CODE BEGIN (18) */
/* USER CODE END */

    return status;
}


/** @fn uint32_t linGetIdentifier(linBASE_t *lin)
*   @brief Get last received identifier
*   @param[in] lin - lin module base address
*
*   @return Identifier
*
*   Read last received identifier.
*/
uint32_t linGetIdentifier(linBASE_t *lin)
{
/* USER CODE BEGIN (19) */
/* USER CODE END */
    return lin->RXID;
}


/** @fn void linGetData(linBASE_t *lin, uint8_t * const data)
*   @brief Read received data
*   @param[in] lin    - lin module base address
*   @param[in] data   - pointer to data buffer
*
*   Read a block of bytes and place it into the data buffer pointed to by 'data'.
*/
void linGetData(linBASE_t *lin, uint8_t * const data)
{
    uint32_t      i;
    uint32_t      length = lin->LENGTH;
    uint8_t *pData = (uint8_t *)data;

/* USER CODE BEGIN (20) */
/* USER CODE END */

    for (i = 0U; i <= length; i++)
    {
        *pData++ = lin->RDx[i];
    }

/* USER CODE BEGIN (21) */
/* USER CODE END */
}


/** @fn linEnableNotification(linBASE_t *lin, uint32_t flags)
*   @brief Enable interrupts
*   @param[in] lin   - lin module base address
*   @param[in] flags - Interrupts to be enabled, can be ored value of:
*                      LIN_BE_INT      - bit error,
*                      LIN_PBE_INT     - physical bus error,
*                      LIN_CE_INT      - checksum error,
*                      LIN_ISFE_INT    - inconsistent sync field error,
*                      LIN_NRE_INT     - no response error,
*                      LIN_FE_INT      - framming error,
*                      LIN_OE_INT      - overrun error,
*                      LIN_PE_INT      - parity error,
*                      LIN_ID_INT      - received matching identifier,
*                      LIN_RX_INT      - receive buffer ready,
*                      LIN_TOA3WUS_INT - time out after 3 wakeup signals,
*                      LIN_TOAWUS_INT  - time out after wakeup signal,
*                      LIN_TO_INT      - time out signal,
*                      LIN_WAKEUP_INT  - wakeup,
*                      LIN_BREAK_INT   - break detect
*/
void linEnableNotification(linBASE_t *lin, uint32_t flags)
{
/* USER CODE BEGIN (22) */
/* USER CODE END */

    lin->SETINT = flags;

/* USER CODE BEGIN (23) */
/* USER CODE END */
}


/** @fn linDisableNotification(linBASE_t *lin, uint32_t flags)
*   @brief Disable interrupts
*   @param[in] lin   - lin module base address
*   @param[in] flags - Interrupts to be disabled, can be ored value of:
*                      LIN_BE_INT      - bit error,
*                      LIN_PBE_INT     - physical bus error,
*                      LIN_CE_INT      - checksum error,
*                      LIN_ISFE_INT    - inconsistent sync field error,
*                      LIN_NRE_INT     - no response error,
*                      LIN_FE_INT      - framming error,
*                      LIN_OE_INT      - overrun error,
*                      LIN_PE_INT      - parity error,
*                      LIN_ID_INT      - received matching identifier,
*                      LIN_RX_INT      - receive buffer ready,
*                      LIN_TOA3WUS_INT - time out after 3 wakeup signals,
*                      LIN_TOAWUS_INT  - time out after wakeup signal,
*                      LIN_TO_INT      - time out signal,
*                      LIN_WAKEUP_INT  - wakeup,
*                      LIN_BREAK_INT   - break detect
*/
void linDisableNotification(linBASE_t *lin, uint32_t flags)
{
/* USER CODE BEGIN (24) */
/* USER CODE END */

    lin->CLRINT = flags;

/* USER CODE BEGIN (25) */
/* USER CODE END */
}


/** @fn void linHighLevelInterrupt(void)
*   @brief Level 0 Interrupt for LIN
*/
#pragma INTERRUPT(linHighLevelInterrupt, IRQ)

void linHighLevelInterrupt(void)
{
    uint32_t vec = linREG->INTVECT0;

/* USER CODE BEGIN (26) */
/* USER CODE END */

    switch (vec)
    {
    case 1:  linNotification(linREG, LIN_WAKEUP_INT);  break;
    case 2:  linNotification(linREG, LIN_ISFE_INT);    break;
    case 3:  linNotification(linREG, LIN_PE_INT);      break;
    case 4:  linNotification(linREG, LIN_ID_INT);      break;
    case 5:  linNotification(linREG, LIN_PBE_INT);     break;
    case 6:  linNotification(linREG, LIN_FE_INT);      break;
    case 7:  linNotification(linREG, LIN_BREAK_INT);   break;
    case 8:  linNotification(linREG, LIN_CE_INT);      break;
    case 9:  linNotification(linREG, LIN_OE_INT);      break;
    case 10: linNotification(linREG, LIN_BE_INT);      break;
    case 11: linNotification(linREG, LIN_RX_INT);      break;
    case 13: linNotification(linREG, LIN_NRE_INT);     break;
    case 14: linNotification(linREG, LIN_TOAWUS_INT);  break;
    case 15: linNotification(linREG, LIN_TOA3WUS_INT); break;
    case 16: linNotification(linREG, LIN_TO_INT);      break;
    default:
        /* phantom interrupt, perform software reset */
        linREG->GCR2 &= ~0x00000080U;
        linREG->GCR2 |=  0x00000080U;
        break;
    }
/* USER CODE BEGIN (27) */
/* USER CODE END */
}


/** @fn void linLowLevelInterrupt(void)
*   @brief Level 1 Interrupt for LIN
*/
#pragma INTERRUPT(linLowLevelInterrupt, IRQ)

void linLowLevelInterrupt(void)
{
    uint32_t vec = linREG->INTVECT1;

/* USER CODE BEGIN (28) */
/* USER CODE END */

    switch (vec)
    {
    case 1:  linNotification(linREG, LIN_WAKEUP_INT);  break;
    case 2:  linNotification(linREG, LIN_ISFE_INT);    break;
    case 3:  linNotification(linREG, LIN_PE_INT);      break;
    case 4:  linNotification(linREG, LIN_ID_INT);      break;
    case 5:  linNotification(linREG, LIN_PBE_INT);     break;
    case 6:  linNotification(linREG, LIN_FE_INT);      break;
    case 7:  linNotification(linREG, LIN_BREAK_INT);   break;
    case 8:  linNotification(linREG, LIN_CE_INT);      break;
    case 9:  linNotification(linREG, LIN_OE_INT);      break;
    case 10: linNotification(linREG, LIN_BE_INT);      break;
    case 11: linNotification(linREG, LIN_RX_INT);      break;
    case 13: linNotification(linREG, LIN_NRE_INT);     break;
    case 14: linNotification(linREG, LIN_TOAWUS_INT);  break;
    case 15: linNotification(linREG, LIN_TOA3WUS_INT); break;
    case 16: linNotification(linREG, LIN_TO_INT);      break;
    default:
        /* phantom interrupt, perform software reset */
        linREG->GCR2 &= ~0x00000080U;
        linREG->GCR2 |=  0x00000080U;
        break;
    }
/* USER CODE BEGIN (29) */
/* USER CODE END */
}

