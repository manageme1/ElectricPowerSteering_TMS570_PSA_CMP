/* ------------------------------------------------------------------------- */
/* fmtm.h : EFUSE FARM  Module Definitions                                          */
/*                                                                           */
/* Copyright (c) Texas Instruments 1997, All right reserved.                 */
/*                                                                           */
/* ------------------------------------------------------------------------- */

#ifndef __EFC_H__
#define __EFC_H__

typedef volatile struct efcBase
{
	unsigned int INSTRUCTION;    			/* 0x0	INSTRUCTION AN DUMPWORD REGISTER	*/
	unsigned int ADDRESS;			    	/* 0x4 ADDRESS REGISTER    					*/
	unsigned int DATA_UPPER;			    /* 0x8 DATA UPPER REGISTER    				*/
	unsigned int DATA_LOWER;				/* 0xc DATA LOWER REGISTER    				*/
	unsigned int SYSTEM_CONFIG;				/* 0x10 SYSTEM CONFIG REGISTER    			*/
	unsigned int SYSTEM_STATUS;				/* 0x14 SYSTEM STATUS REGISTER    			*/
	unsigned int ACCUMULATOR;				/* 0x18 ACCUMULATOR REGISTER    			*/
	unsigned int BOUNDARY;			    	/* 0x1C BOUNDARY REGISTER 					*/
	unsigned int KEY_FLAG;			    	/* 0x20 KEY FLAG REGISTER    				*/
	unsigned int KEY;			        	/* 0x24	KEY REGISTER 						*/
	unsigned int : 32;				        /* 0x28	RESERVED 							*/
	unsigned int PINS;				        /* 0x2C  PINS REGISTER						*/
	unsigned int CRA;				        /* 0x30  CRA								*/
	unsigned int READ;				        /* 0x34 READ REGISTER						*/
	unsigned int PROGRAMME;				    /* 0x38 PROGRAMME REGISTER					*/
	unsigned int ERROR;				        /* 0x3C	ERROR STATUS REGISTER				*/
	unsigned int SINGLE_BIT;				/* 0x40	SINGLE BIT ERROR 					*/
	unsigned int TWO_BIT_ERROR;				/* 0x44	DOUBLE BIT ERROR 					*/
	unsigned int SELF_TEST_CYCLES;			/* 0x48	SELF TEST CYCLEX					*/
	unsigned int SELF_TEST_SIGN;			/* 0x4C SELF TEST SIGNATURE					*/
} efcBASE_t;

#define efcREG   ((efcBASE_t *)0xFFF8C000U)

#define INPUT_ENABLE         0x0000000F    // 3:0
#define INPUT_DISABLE        0x00000000    // 3:0

#define SYS_WS_READ_STATES   0x00000000    // 7:4  - input


#define SYS_REPAIR_EN_0      0x00000000    // 9:8  - input   no of repair rows -1
#define SYS_REPAIR_EN_3      0x00000100    // 9:8  - input   no of repair rows -3
#define SYS_REPAIR_EN_5      0x00000200    // 9:8  - input   no of repair rows -5

#define SYS_DEID_AUTOLOAD_EN 0x00000400    // 10   - input
#define SYS_DEID_AUTOLOAD_EN 0x00000400    // 10   - input

#define EFC_FDI_EN            0x00000800    // 11   - input
#define EFC_FDI_DIS           0x00000000    // 11   - input

#define SYS_ECC_OVERRIDE_EN   0x00001000             // 12   - input
#define SYS_ECC_OVERRIDE_DIS  0x00000000             // 12   - input

#define SYS_ECC_SELF_TEST_EN  0x00002000 // 13 - INPUT 
#define SYS_ECC_SELF_TEST_DIS 0x00000000 // 13 - INPUT

#define OUTPUT_ENABLE         0x0003C000 // 17:14 output 
#define OUTPUT_DISABLE        0x00000000 // 17:14 output 

/*********** OUTPUT **************/

#define EFC_AUTOLOAD_ERROR_EN    0x00040000 //18 OUTPUT
#define EFC_INSTRUCTION_ERROR_EN 0x00080000 //19 OUTPUT
#define EFC_INSTRUCTION_INFO_EN  0x00100000 //20 output
#define EFC_SELF_TEST_ERROR_EN   0x00200000 //21 output


#define EFC_AUTOLOAD_ERROR_DIS    0x00000000 //18 OUTPUT
#define EFC_INSTRUCTION_ERROR_DIS 0x00000000 //19 OUTPUT
#define EFC_INSTRUCTION_INFO_DIS  0x00000000 //20 output
#define EFC_SELF_TEST_ERROR_DIS   0x00000000 //21 output

 // 22 BIT RESERVED

#define DISABLE_READ_ROW0     0x00800000 //23 

/********************************************************************/

#define SYS_REPAIR_0         0x00000010    // 
#define SYS_REPAIR_3         0x00000010    // 
#define SYS_REPAIR_5         0x00000020    //  5:4

#define SYS_DEID_AUTOLOAD    0x00000040 //6
#define SYS_FCLRZ            0x00000080 //7
#define EFC_READY            0x00000100 //8
#define SYS_ECC_OVERRIDE     0x00000200 //9
#define EFC_AUTOLOAD_ERROR   0x00000400 // 10
#define EFC_INSTRUCTION_ERROR 0x00000800 //11
#define EFC_INSTRUCTION_INFO  0x00001000 //12
#define SYS_ECC_SELF_TEST    0x00002000 //13
#define EFC_SELF_TEST_ERROR  0x00004000 //14
#define EFC_SELF_TEST_DONE   0x00008000 //15



/**************   0x3C error status register ******************************************************/

#define TIME_OUT 0x01
#define AUTOLOAD_NO_FUSEROM_DATA 0x02 
#define AUTOLOAD_SIGN_FAIL       0x03
#define AUTOLOAD_PROG_INTERRUPT  0x04
#define AUTOLOAD_TWO_BIT_ERR     0x05
#define PROGRAME_WR_P_SET        0x06
#define PROGRAME_MNY_DATA_ITERTN      0x07
#define PROGRAME_MNY_CNTR_ITERTN      0x08
#define UN_PROGRAME_BIT_SET           0x09
#define REDUNDANT_REPAIR_ROW          0x0A
#define PROGRAME_MNY_CRA_ITERTN       0x0B
#define PROGRAME_SAME_DATA            0x0C
#define PROGRAME_CMP_SKIP			  0x0D
#define PROGRAME_ABORT                0x0E
#define PROGRAME_INCORRECT_KEY		  0x0F
#define FUSEROM_LASTROW_STUCK		  0x10
#define AUTOLOAD_SINGLE_BIT_ERR		  0x15
#define DUMPWORD_TWO_BIT_ERR	      0x16
#define DUMPWORD_ONE_BIT_ERR          0x17
#define SELF_TEST_ERROR               0x18


#define INSTRUCTION_DONE              0x20





/**************   Efuse Instruction set ******************************************************/

#define TEST_UNPROGRAME_ROM  0x01000000
#define PROGRAME_CRA         0x02000000  
#define DUMP_WORD            0x04000000
#define LOAD_FUSE_SCAN_CHAIN 0x05000000
#define PROGRAME_DATA        0x07000000
#define RUN_AUTOLOAD_8       0x08000000
#define RUN_AUTOLOAD_A       0x0A000000

#endif

